<div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>About Us</h2>
        </div>

        <div class="row content">
          <?php
            $about = $cmsText->aboutUsText;
            $length = strlen($about)/2;
            $split = str_split($about , $length);

          ?>
          <?php if(auth()->guard()->guest()): ?>
          <div class="col-lg-6">
            <p>
              <?php echo e($split[0]); ?>

            </p>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p>
              <?php echo e($split[1]); ?>

            </p>
            <a href="#" class="btn-learn-more">Learn More</a>
          </div>
          <?php endif; ?>
          <?php if(auth()->guard()->check()): ?>
          <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('aboutus', [])->html();
} elseif ($_instance->childHasBeenRendered('5s4D5iW')) {
    $componentId = $_instance->getRenderedChildComponentId('5s4D5iW');
    $componentTag = $_instance->getRenderedChildComponentTagName('5s4D5iW');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5s4D5iW');
} else {
    $response = \Livewire\Livewire::mount('aboutus', []);
    $html = $response->html();
    $_instance->logRenderedChild('5s4D5iW', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?> 
          <?php endif; ?>
        </div>

      </div><?php /**PATH C:\swapin\example-app\resources\views/welcome/sections/about.blade.php ENDPATH**/ ?>