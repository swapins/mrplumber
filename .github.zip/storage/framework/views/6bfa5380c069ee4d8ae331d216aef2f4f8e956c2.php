<h1 class="logo me-auto"><a href="index.html">Arsha</a></h1>
<!-- Uncomment below if you prefer to use an image logo -->
<!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->
      <?php /**PATH C:\swapin\example-app\resources\views/welcome/components/logo.blade.php ENDPATH**/ ?>