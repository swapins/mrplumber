<div
    style="width: 100%; height: 100%;"
    x-data="{ ...livewireChartsColumnChart() }"
    x-init="init()"
>
    <div wire:ignore x-ref="container"></div>
</div>

<?php /**PATH C:\swapin\example-app\vendor\asantibanez\livewire-charts\src/../resources/views/livewire-column-chart.blade.php ENDPATH**/ ?>