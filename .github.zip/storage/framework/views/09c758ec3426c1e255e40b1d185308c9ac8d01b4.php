<!-- Vendor JS Files -->
<script src="./welcome/assets/vendor/aos/aos.js"></script>
  <script src="./welcome/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="./welcome/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="./welcome/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="./welcome/assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="./welcome/assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="./welcome/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="./welcome/assets/js/main.js"></script><?php /**PATH C:\swapin\example-app\resources\views/welcome/components/scripts.blade.php ENDPATH**/ ?>