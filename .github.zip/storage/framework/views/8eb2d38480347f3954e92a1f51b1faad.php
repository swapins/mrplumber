<div class="container mx-auto space-y-4 p-4 sm:p-0 mt-8">
    <div class="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
        <div class="shadow rounded p-4 border bg-white flex-none basis-1/3" style="height: 32rem;">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-column-chart', ['columnChartModel' => $columnChartModel])->html();
} elseif ($_instance->childHasBeenRendered(''.e($columnChartModel->reactiveKey()).'')) {
    $componentId = $_instance->getRenderedChildComponentId(''.e($columnChartModel->reactiveKey()).'');
    $componentTag = $_instance->getRenderedChildComponentTagName(''.e($columnChartModel->reactiveKey()).'');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(''.e($columnChartModel->reactiveKey()).'');
} else {
    $response = \Livewire\Livewire::mount('livewire-column-chart', ['columnChartModel' => $columnChartModel]);
    $html = $response->html();
    $_instance->logRenderedChild(''.e($columnChartModel->reactiveKey()).'', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

        <div class="shadow rounded p-4 border bg-white flex-none basis-2/3" style="height: 32rem;">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $pieChartModel])->html();
} elseif ($_instance->childHasBeenRendered(''.e($pieChartModel->reactiveKey()).'')) {
    $componentId = $_instance->getRenderedChildComponentId(''.e($pieChartModel->reactiveKey()).'');
    $componentTag = $_instance->getRenderedChildComponentTagName(''.e($pieChartModel->reactiveKey()).'');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild(''.e($pieChartModel->reactiveKey()).'');
} else {
    $response = \Livewire\Livewire::mount('livewire-pie-chart', ['pieChartModel' => $pieChartModel]);
    $html = $response->html();
    $_instance->logRenderedChild(''.e($pieChartModel->reactiveKey()).'', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

    </div>
</div>

<?php /**PATH C:\swapin\example-app\resources\views/livewire/livewire-charts.blade.php ENDPATH**/ ?>