<div>
    <button type="button"
        wire:click="$toggle('showDiv')"
        class="btn btn-primary"><i class="bi bi-pencil-square"></i>
    </button>
    <div class="container" style="padding-top:10px;">
        <?php if($showDiv): ?>
        <div class="row">
            <div class="col-10">
                <input  type="text"
                        style="
                            width:100%;
                            padding: 8px 15px;
                            margin: 8px 0;
                            box-sizing: border-box;
                            border: none;
                            border-bottom: 2px solid white;
                            background: transparent;
                            color: white;
                            outline: none;"
                        wire:model="cmsText.title"
                />
                <?php $__errorArgs = ['cmsText.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-2">
                <button class="btn btn-primary" wire:click="saveTitle">Save</button>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\swapin\example-app\resources\views/livewire/hero.blade.php ENDPATH**/ ?>