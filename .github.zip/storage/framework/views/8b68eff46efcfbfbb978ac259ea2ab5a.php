<div class="bg-primary rounded h-100 d-flex align-items-center p-5 wow zoomIn" data-wow-delay="0.9s">
    <form wire:submit.prevent="save">
        <div class="row g-3">
            <div class="col-xl-12">
                <input type="text" class="form-control bg-light border-0" placeholder="Your Name" style="height: 55px;"
                wire:model="contact.name">
            </div>
            <div class="col-12">
                <input type="email" class="form-control bg-light border-0" 
                wire:model="contact.email" placeholder="Your Email" style="height: 55px;">
            </div>
            <div class="col-12">
                <select class="form-select bg-light border-0" style="height: 55px;" wire:model="contact.subject">
                    <option selected>Select A Service</option>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($service->serviceName); ?>"><?php echo e($service->serviceName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-12">
                <textarea class="form-control bg-light border-0" rows="3" placeholder="Message" wire:model="contact.message"></textarea>
            </div>
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                Your message has been sent. Thank you!
            </div>
            <?php endif; ?>

            <div class="col-12">
                <button class="btn btn-dark w-100 py-3" type="submit">Request A Quote</button>
            </div>
        </div>
    </form>
</div>
<?php /**PATH C:\swapin\example-app\resources\views/livewire/contact.blade.php ENDPATH**/ ?>