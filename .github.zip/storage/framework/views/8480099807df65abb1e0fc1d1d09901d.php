<td class="<?php echo e($theme->tdBodyClass); ?>"
    style="<?php echo e($theme->tdBodyStyle); ?>">
    <div class="cursor-pointer" x-on:click.prevent="$wire.toggleDetail('<?php echo e($row->{$primaryKey}); ?>')">
        <?php if ($__env->exists(data_get($setUp, 'detail.viewIcon'))) echo $__env->make(data_get($setUp, 'detail.viewIcon'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if(!data_get($setUp, 'detail.viewIcon')): ?>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'livewire-powergrid::components.icons.arrow','data' => ['class' => 'text-gray-600 w-5 h-5 transition-all duration-300 dark:text-slate-200','xBind:class' => 'detailState ? \'rotate-90\': \'-rotate-0\'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('livewire-powergrid::icons.arrow'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-gray-600 w-5 h-5 transition-all duration-300 dark:text-slate-200','x-bind:class' => 'detailState ? \'rotate-90\': \'-rotate-0\'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        <?php endif; ?>
    </div>
</td>
<?php /**PATH C:\swapin\example-app\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/frameworks/tailwind/toggle-detail.blade.php ENDPATH**/ ?>