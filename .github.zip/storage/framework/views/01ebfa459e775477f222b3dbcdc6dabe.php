<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
            <?php echo e(__('Update Site Details')); ?>

        </h2>

        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            <?php echo e(__('Ensure your data is devoid of typoos as it is served publically.')); ?>

        </p>
    </header>

    <div class="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 mt-2">
        
        <div class="shadow rounded p-4 border bg-white flex-none basis-1/2">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('siteinfo', [])->html();
} elseif ($_instance->childHasBeenRendered('jptF5nG')) {
    $componentId = $_instance->getRenderedChildComponentId('jptF5nG');
    $componentTag = $_instance->getRenderedChildComponentTagName('jptF5nG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jptF5nG');
} else {
    $response = \Livewire\Livewire::mount('siteinfo', []);
    $html = $response->html();
    $_instance->logRenderedChild('jptF5nG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>   
        </div>
        <div class="shadow rounded p-4 border bg-white flex-none basis-1/2">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sitesocial', [])->html();
} elseif ($_instance->childHasBeenRendered('2tll37Y')) {
    $componentId = $_instance->getRenderedChildComponentId('2tll37Y');
    $componentTag = $_instance->getRenderedChildComponentTagName('2tll37Y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2tll37Y');
} else {
    $response = \Livewire\Livewire::mount('sitesocial', []);
    $html = $response->html();
    $_instance->logRenderedChild('2tll37Y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <div class="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 mt-4">
        <div class="shadow rounded p-4 border bg-white flex-none w-full">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('siteother', [])->html();
} elseif ($_instance->childHasBeenRendered('lcgRj0z')) {
    $componentId = $_instance->getRenderedChildComponentId('lcgRj0z');
    $componentTag = $_instance->getRenderedChildComponentTagName('lcgRj0z');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lcgRj0z');
} else {
    $response = \Livewire\Livewire::mount('siteother', []);
    $html = $response->html();
    $_instance->logRenderedChild('lcgRj0z', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>

    
</section>
<?php /**PATH C:\swapin\example-app\resources\views/dashboard/partials/sitesettings.blade.php ENDPATH**/ ?>