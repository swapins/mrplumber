
<?php $__env->startSection('main'); ?>
<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="index.html">Home</a></li>
      <li><?php echo e($service->serviceName); ?></li>
    </ol>
  </div>
</section>
<!-- End Breadcrumbs -->

<section class="services section">
<div class="container" data-aos="fade-up">

<div class="section-title">
  <h2><?php echo e($service->serviceName); ?></h2>
  <p><?php echo e($service->dec); ?></p>
</div>

  <div class="row">
      <div class="col-md-6 col-sm-12 text-center">
        <img src="https://picsum.photos/300/300">
      </div>
  </div>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.innerpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swapin\example-app\resources\views/welcome/pages/services.blade.php ENDPATH**/ ?>