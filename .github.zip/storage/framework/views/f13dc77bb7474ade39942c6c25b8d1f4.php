<svg <?php echo e($attributes); ?> fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
    <path stroke-linecap="round" stroke-linejoin="round" d="M9 5l7 7-7 7" />
</svg>
<?php /**PATH C:\swapin\example-app\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/icons/arrow.blade.php ENDPATH**/ ?>