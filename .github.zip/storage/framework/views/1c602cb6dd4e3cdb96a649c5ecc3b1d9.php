<div x-data="pgToggleable({
            id: '<?php echo e($row->{$primaryKey}); ?>',
            isHidden: <?php echo e(!$showToggleable ? 'true' : 'false'); ?>,
            tableName: '<?php echo e($tableName); ?>',
            field: '<?php echo e($column->field); ?>',
            toggle: <?php echo e((int) $row->{$column->field}); ?>,
            trueValue: '<?php echo e($column->toggleable['default'][0]); ?>',
            falseValue:  '<?php echo e($column->toggleable['default'][1]); ?>'
         })">
    <?php if($column->toggleable['enabled'] && $showToggleable === true): ?>
        <div class="form-check form-switch">
            <label>
                <input x-on:click="save()"
                       class="form-check-input"
                       :checked="toggle === 1"
                       type="checkbox">
            </label>
        </div>
    <?php else: ?>
        <div class="text-center">
            <?php if($row->{$column->field} == 0): ?>
                <div  x-text="falseValue"
                      style="padding-top: 0.1em; padding-bottom: 0.1rem"
                     class="badge bg-danger">
                </div>
            <?php else: ?>
                <div x-text="trueValue"
                     style="padding-top: 0.1em; padding-bottom: 0.1rem"
                     class="badge bg-success">
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php /**PATH C:\swapin\example-app\vendor\power-components\livewire-powergrid\src\Providers/../../resources/views/components/frameworks/bootstrap5/toggleable.blade.php ENDPATH**/ ?>