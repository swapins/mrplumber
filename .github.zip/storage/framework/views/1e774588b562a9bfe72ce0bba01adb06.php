<div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-6 d-flex align-items-center" data-aos="fade-right" data-aos-delay="100">
            <img src="assets/img/skills.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content" data-aos="fade-left" data-aos-delay="100">
            <h3>Our Success Stories</h3>
            <p class="fst-italic">
              "If I had my life to live over again, I’d be a plumber”
              <quote>Albert Einstein</quote>
            </p>

            <div class="skills-content">

              <div class="progress">
                <span class="skill"><i class="bi bi-buildings fs-5 "></i>&nbsp;&nbsp;Commercial Plumbing<i class="val">100%</i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div class="progress">
                <span class="skill"><i class="bi bi-house-door  fs-5 "></i>&nbsp;&nbsp;Residential Plumbing<i class="val">90%</i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div class="progress">
                <span class="skill"><i class="bi bi-moisture  fs-5 "></i>&nbsp;&nbsp;Galvanized plumbing <i class="val">75%</i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div class="progress">
                <span class="skill"><i class="bi bi-recycle  fs-5 "></i>&nbsp;&nbsp;Sewage water plumbing <i class="val">55%</i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

            </div>

          </div>
        </div>
      </div><?php /**PATH C:\swapin\example-app\resources\views/welcome/sections/skills.blade.php ENDPATH**/ ?>