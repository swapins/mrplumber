<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Frequently asked questions')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div>
        
        <div class="w-full px-4 py-2 bg-gray-200 lg:w-full">
            <div class="container mx-auto mt-12">
                <div>
                    <div class="w-full">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('faq', [])->html();
} elseif ($_instance->childHasBeenRendered('xXYNxRs')) {
    $componentId = $_instance->getRenderedChildComponentId('xXYNxRs');
    $componentTag = $_instance->getRenderedChildComponentTagName('xXYNxRs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('xXYNxRs');
} else {
    $response = \Livewire\Livewire::mount('faq', []);
    $html = $response->html();
    $_instance->logRenderedChild('xXYNxRs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </div>
                <div class="flex flex-col mt-8">
                    <div class="py-2 -my-2 overflow-x-auto sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
                        <div
                            class="inline-block min-w-full overflow-hidden align-middle border-b border-gray-200 shadow-lg sm:rounded-lg">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('faq-table', [])->html();
} elseif ($_instance->childHasBeenRendered('Ovdyoxq')) {
    $componentId = $_instance->getRenderedChildComponentId('Ovdyoxq');
    $componentTag = $_instance->getRenderedChildComponentTagName('Ovdyoxq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Ovdyoxq');
} else {
    $response = \Livewire\Livewire::mount('faq-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('Ovdyoxq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\swapin\example-app\resources\views/faq.blade.php ENDPATH**/ ?>