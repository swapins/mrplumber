<!--<h1 class="logo me-auto"><a href="index.html">Arsha</a></h1>-->
<!-- Uncomment below if you prefer to use an image logo -->
<a href="/" class="logo me-auto">
    <img src="./welcome/assets/img/logo/mrlogo_white.png" alt="" class="img-fluid">
    <img src="./welcome/assets/img/logo/mrlogo_white_txt.png" alt="" class="img-fluid">
</a>
<?php if(auth()->guard()->check()): ?>
<a type="button" href="<?php echo e(route('dashboard')); ?>" class="btn btn-sm btn-danger">Admin Mode</a>
<?php endif; ?>
<?php /**PATH C:\swapin\example-app\resources\views/welcome/components/logo.blade.php ENDPATH**/ ?>