
<?php $__env->startSection('hero'); ?>
    <?php echo $__env->make('welcome.sections.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    
    <!-- ======= Clients Section ======= -->
        <section id="clients" class="clients section-bg">
            <?php echo $__env->make('welcome.sections.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    <!-- End Cliens Section -->

    <!-- ======= About Us Section ======= -->
        <section id="about" class="about">
            <?php echo $__env->make('welcome.sections.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    <!-- End About Us Section -->

    <!-- ======= Why Us Section ======= -->
        <section id="why-us" class="why-us section-bg">
            <?php echo $__env->make('welcome.sections.why-us', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    <!-- End Why Us Section -->

    <!-- ======= Skills Section ======= -->
        <section id="skills" class="skills">
            <?php echo $__env->make('welcome.sections.skills', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    <!-- End Skills Section -->

    <!-- ======= Services Section ======= -->
        <section id="services" class="services section-bg">
            <?php echo $__env->make('welcome.sections.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    <!-- End Services Section -->

    <!-- ======= Cta Section ======= -->
        <section id="cta" class="cta">
            <?php echo $__env->make('welcome.sections.cta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    <!-- End Cta Section -->

    <!-- ======= Frequently Asked Questions Section ======= -->
        <section id="faq" class="faq section-bg">
            <?php echo $__env->make('welcome.sections.faq', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    <!-- End Frequently Asked Questions Section -->

    <!-- ======= Contact Section ======= -->
        <section id="contact" class="contact">
            <?php echo $__env->make('welcome.sections.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    <!-- End Contact Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swapin\example-app\resources\views/welcome/pages/home.blade.php ENDPATH**/ ?>