<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
            <?php echo e(__('Basic Site Analytics')); ?>

        </h2>

        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            <?php echo e(__('Your Site data shown.')); ?>

        </p>
    </header>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-charts', [])->html();
} elseif ($_instance->childHasBeenRendered('WMgPFzj')) {
    $componentId = $_instance->getRenderedChildComponentId('WMgPFzj');
    $componentTag = $_instance->getRenderedChildComponentTagName('WMgPFzj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WMgPFzj');
} else {
    $response = \Livewire\Livewire::mount('livewire-charts', []);
    $html = $response->html();
    $_instance->logRenderedChild('WMgPFzj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</section>
<?php /**PATH C:\swapin\example-app\resources\views/dashboard/partials/analytics.blade.php ENDPATH**/ ?>