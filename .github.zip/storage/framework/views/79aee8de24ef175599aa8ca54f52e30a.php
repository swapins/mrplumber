<!doctype html>
<html lang="en" class="h-full bg-gray-100">
<head>
<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">
        <?php echo \Livewire\Livewire::styles(); ?>

        <?php echo view('livewire-powergrid::assets.styles')->render(); ?>

        <!-- Scripts -->
         
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="h-full">
    //

</body>
</html>
<?php /**PATH C:\swapin\example-app\resources\views/mrplumber.blade.php ENDPATH**/ ?>