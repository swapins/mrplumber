<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('welcome.components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- =======================================================
    * Template Name: SPM - v4.10.0
    * Template URL:
    * Author: swapin vidya
    * License: /license/
    ======================================================== -->
    <!-- Livewire -->
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner"></div>
    </div>
    <!-- Spinner End -->

    <!-- Topbar Start -->
    <?php echo $__env->make('welcome.components.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Topbar End -->

    <!-- Navbar & Carousel Start -->
    <div class="container-fluid position-relative p-0">
        <!-- Nav -->
        <?php echo $__env->make('welcome.components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Nav End -->
        <?php
            if (request()->routeIs('about')){
                $url = "../newdesigin/img/carousel-1.jpg";
            }
            elseif (request()->routeIs('brand')){
                $url = "../newdesigin/img/bg/01.jpg";
            }
            elseif (request()->routeIs('service')){
                $url = "../newdesigin/img/bg/02.jpg";
            }
            elseif (request()->routeIs('quote')){
                $url = "../newdesigin/img/bg/quote.jpg";
            }
            else{
                $url = "../newdesigin/img/bg/contact.jpg";
            }
        ?>
        <div class="container-fluid bg-primary py-5 bg-header"
            style="
                margin-bottom: 10px;
                background-size: cover;
                background: linear-gradient(rgba(9, 30, 62, .7), rgba(9, 30, 62, .5)),
                url(<?php echo e($url); ?>);
                background-repeat: no-repeat;
                background-size: cover;">
            <div class="row py-5">
                <div class="col-12 pt-lg-5 mt-lg-5 text-center">

                    <?php if(request()->routeIs('about')): ?>
                    <h1 class="display-4 text-white animated zoomIn">About Us</h1>
                    <a href="/" class="h5 text-white">Home</a>
                    <i class="far fa-circle text-white px-2"></i>
                    <a href="<?php echo e(url()->previous()); ?>" class="h5 text-white">About</a>
                    <?php elseif(request()->routeIs('brand')): ?>
                    <h1 class="display-4 text-white animated zoomIn">Brands</h1>
                    <a href="/" class="h5 text-white">Home</a>
                    <i class="far fa-circle text-white px-2"></i>
                    <a href="<?php echo e(url()->previous()); ?>" class="h5 text-white">Brand</a>

                    <?php elseif(request()->routeIs('service')): ?>
                    <h1 class="display-4 text-white animated zoomIn">Services we offer</h1>
                    <a href="/" class="h5 text-white">Home</a>
                    <i class="far fa-circle text-white px-2"></i>
                    <a href="<?php echo e(url()->previous()); ?>" class="h5 text-white">Services</a>

                    <?php elseif(request()->routeIs('quote')): ?>
                    <h1 class="display-4 text-white animated zoomIn">Free Quote</h1>
                    <a href="/" class="h5 text-white">Home</a>
                    <i class="far fa-circle text-white px-2"></i>
                    <a href="<?php echo e(url()->previous()); ?>" class="h5 text-white">Quote</a>

                    <?php else: ?>
                    <h1 class="display-4 text-white animated zoomIn">Contact</h1>
                    <a href="/" class="h5 text-white">Home</a>
                    <i class="far fa-circle text-white px-2"></i>
                    <a href="<?php echo e(url()->previous()); ?>" class="h5 text-white">Contact</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar & Carousel End -->

    <!-- Full Screen Search Start -->
    <div class="modal fade" id="searchModal" tabindex="-1">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content" style="background: rgba(9, 30, 62, .7);">
                <div class="modal-header border-0">
                    <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body d-flex align-items-center justify-content-center">
                    <div class="input-group" style="max-width: 600px;">
                        <input type="text" class="form-control bg-transparent border-primary p-3" placeholder="Type search keyword">
                        <button class="btn btn-primary px-4"><i class="bi bi-search"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Full Screen Search End -->



    <?php echo $__env->yieldContent('main'); ?>


    <!-- Vendor Start -->
    <div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container py-5 mb-5">
            <div class="bg-white">
                <div class="owl-carousel vendor-carousel">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barnd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e($barnd->logo); ?>" alt="">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Vendor End -->


    <!-- Footer Start -->
    <?php echo $__env->make('welcome.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- Livewire -->
    <?php echo \Livewire\Livewire::scripts(); ?>

    <!-- JavaScript Libraries -->
    <?php echo $__env->make('welcome.components.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





</body>

</html>
<?php /**PATH C:\swapin\example-app\resources\views/layouts/innerpage.blade.php ENDPATH**/ ?>