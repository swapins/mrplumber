
<?php $__env->startSection('main'); ?>
<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
  <div class="container">

    <ol>
      <li><a href="index.html">Home</a></li>
      <li><?php echo e($service->serviceName); ?></li>
    </ol>
    <h2><?php echo e($service->serviceName); ?></h2>

  </div>
</section>
<!-- End Breadcrumbs -->

<section class="inner-page">
  <div class="container">
    <h1><?php echo e($service->serviceName); ?></h1>
    <p>
      <?php echo e($service->dec); ?>

    </p>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.innerpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\swapin\example-app\resources\views/welcome/pages/services.blade.php ENDPATH**/ ?>