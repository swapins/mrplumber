<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('welcome.components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- =======================================================
  * Template Name: Arsha - v4.10.0
  * Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top header-inner-pages">
    <div class="container d-flex align-items-center">
        <?php echo $__env->make('welcome.components.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('welcome.components.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

  </header><!-- End Header -->

  <main id="main">
    <?php echo $__env->yieldContent('main'); ?>
    <!-- ======= Clients Section ======= -->
    <section id="clients" class="clients section-bg">
        <?php echo $__env->make('welcome.sections.clients', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <!-- End Cliens Section -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
        <?php echo $__env->make('welcome.sections.cta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>
    <!-- End Cta Section -->
  </main>

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <?php echo $__env->make('welcome.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <?php echo $__env->make('welcome.components.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
</body>

</html><?php /**PATH C:\swapin\example-app\resources\views/layouts/innerpage.blade.php ENDPATH**/ ?>