<div>
    <p>
        Dish has <?php echo e($row->calories); ?> (<?php echo e($options['message']); ?>)
    </p>

    <div class="flex justify-begin">
        <button wire:click.prevent="toggleDetail('<?php echo e($id); ?>')" class="mt-2 p-1 text-xs bg-red-600 text-white rounded-lg">Close</button>
    </div>
</div><?php /**PATH C:\swapin\example-app\resources\views/components/detail.blade.php ENDPATH**/ ?>