<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">
        @livewireStyles
        @powerGridStyles

        <!-- Scripts -->
         
        @vite(['resources/css/app.css', 'resources/js/app.js'])
       
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100 dark:bg-gray-900">
            @include('layouts.navigation')

            <!-- Page Heading -->
            @if (isset($header))
                <header class="bg-white dark:bg-gray-800 shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        {{ $header }}
                    </div>
                </header>
            @endif

            <!-- Page Content -->
            <main>
                {{ $slot }}
            </main>
        </div>

        <footer
            class="bg-blue-200 text-center dark:bg-neutral-700 lg:text-left shadow-lg">
            <div class="p-4 text-center text-neutral-700 dark:text-neutral-200">
                © 2023 Copyright:
                <a
                class="text-neutral-800 dark:text-neutral-400"
                href="/"
                >SP Managers Snd Bhd. Cyberjaya MY</a
                >
            </div>
        </footer>
        <!-- Scripts -->
        
        <script src="https://code.jquery.com/jquery-3.6.0.slim.min.js"></script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" 
                integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" 
                crossorigin="anonymous"></script>
                
        @livewireScripts
        @livewireChartsScripts
        @powerGridScripts
       
    </body>
</html>
