<div class="container">
    <div class="row" data-aos="zoom-in">

        <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
        <img src=".\welcome\assets\img\brands\ASTRAL.png" class="img-fluid" alt="">
        </div>

        <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
        <img src=".\welcome\assets\img\brands\Cera.png" class="img-fluid" alt="">
        </div>

        <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
        <img src=".\welcome\assets\img\brands\PRINCE.png" class="img-fluid" alt="">
        </div>

        <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
        <img src=".\welcome\assets\img\brands\Hindware.png" class="img-fluid" alt="">
        </div>

        <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
        <img src=".\welcome\assets\img\brands\jaguar.png" class="img-fluid" alt="">
        </div>

        <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
        <img src=".\welcome\assets\img\brands\parrywear.png" class="img-fluid" alt="">
        </div>

    </div>
</div>