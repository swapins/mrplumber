    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
                    $(".nav .nav-link").on("click", function(){
                        alert('nav');
                    $(".nav").find(".active").removeClass("active");
                    $(this).addClass("active");
                });

    </script>
    <script src="./newdesigin/lib/wow/wow.min.js"></script>
    <script src="newdesigin/lib/easing/easing.min.js"></script>
    <script src="./newdesigin/lib/waypoints/waypoints.min.js"></script>
    <script src="./newdesigin/lib/counterup/counterup.min.js"></script>
    <script src="./newdesigin/lib/owlcarousel/owl.carousel.min.js"></script>
    <!-- Template Javascript -->
    <script src="./newdesigin/js/main.js"></script>

