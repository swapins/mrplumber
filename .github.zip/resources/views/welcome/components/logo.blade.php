<!--<h1 class="logo me-auto"><a href="index.html">Arsha</a></h1>-->
<!-- Uncomment below if you prefer to use an image logo -->
<a href="/" class="logo me-auto">
    <img src="./welcome/assets/img/logo/mrlogo_white.png" alt="" class="img-fluid">
    <img src="./welcome/assets/img/logo/mrlogo_white_txt.png" alt="" class="img-fluid">
</a>
@auth
<a type="button" href="{{route('dashboard')}}" class="btn btn-sm btn-danger">Admin Mode</a>
@endauth
